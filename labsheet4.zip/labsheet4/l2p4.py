# Rotate a list by n positions

num = list(map(int, input("Enter numbers: ").split()))
n = int(input("Enter number of positions: "))

n = n % len(num)

rot = num[-n:] + num[:-n]

print("Rotated list:", rot)
