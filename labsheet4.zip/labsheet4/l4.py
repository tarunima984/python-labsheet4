Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

======== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p1l4.py =======
Enter numbers separated by space: 34 67 24 78 98
List: [34, 67, 24, 78, 98]
Sum: 301
Average: 60.2

======== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p2l4.py =======
Enter numbers: 377 48 66 29 3 0
Enter number of positions: 4
Rotated list: [66, 29, 3, 0, 377, 48]

====== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p3l4.py ======
Enter numbers: 56 78 468 79 34 90
List after removing negative numbers: [56, 78, 468, 79, 34, 90]

====== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p3l4.py ======
Enter numbers: 56 78 -468 -79 34 90 78-4
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p3l4.py", line 3, in <module>
    n = list(map(int, input("Enter numbers: ").split()))
ValueError: invalid literal for int() with base 10: '78-4'

====== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p3l4.py ======
Enter numbers: 56 78 -468 -79 34 90
List after removing negative numbers: [56, 78, 34, 90]

============== RESTART: C:/Users/hp/OneDrive/Documents/p4l4.py ==============
Enter numbers: 67 37 56 78 -468 -79 34 90
Product: 1225049189495040

============== RESTART: C:/Users/hp/OneDrive/Documents/p5l4.py ==============
Enter n: 78 35
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p5l4.py", line 3, in <module>
    n = int(input("Enter n: "))
ValueError: invalid literal for int() with base 10: '78 35'

============== RESTART: C:/Users/hp/OneDrive/Documents/p5l4.py ==============
Enter n: 45
List of squares: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625, 676, 729, 784, 841, 900, 961, 1024, 1089, 1156, 1225, 1296, 1369, 1444, 1521, 1600, 1681, 1764, 1849, 1936, 2025]

============== RESTART: C:/Users/hp/OneDrive/Documents/p5l4.py ==============
Enter n: 15
List of squares: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225]

============== RESTART: C:/Users/hp/OneDrive/Documents/p6l4.py ==============
Enter numbers: 67 36 68 39 -9
First half: [67, 36]
Second half: [68, 39, -9]

============== RESTART: C:/Users/hp/OneDrive/Documents/p7l4.py ==============
Enter numbers: 400, 441, 484, 529, 576
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p7l4.py", line 3, in <module>
    n = list(map(int, input("Enter numbers: ").split()))
ValueError: invalid literal for int() with base 10: '400,'

============== RESTART: C:/Users/hp/OneDrive/Documents/p7l4.py ==============
Enter numbers: 10 6 8
List is not sorted.

============== RESTART: C:/Users/hp/OneDrive/Documents/p7l4.py ==============
Enter numbers: 34 56 78 89
List is sorted.

============== RESTART: C:/Users/hp/OneDrive/Documents/p8l4.py ==============
Enter numbers: 67 34 89 90 567
Enter target sum: 689
No pair found.

============== RESTART: C:/Users/hp/OneDrive/Documents/p8l4.py ==============
Enter numbers: 67 34 89 90 567 11
Enter target sum: 100
Pair: 89 11

============== RESTART: C:/Users/hp/OneDrive/Documents/p9l4.py ==============
Nested list: [[1, 2], [3, 4], [5, 6]]
Flattened list: [1, 2, 3, 4, 5, 6]

============== RESTART: C:/Users/hp/OneDrive/Documents/p10l4.py =============
Enter list elements: 29 40 60 28
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p10l4.py", line 7, in <module>
    for itm in items:
NameError: name 'items' is not defined. Did you mean: 'iter'?

============== RESTART: C:/Users/hp/OneDrive/Documents/p10l4.py =============
Enter list elements: 29 40 60 28
String: 29406028

============== RESTART: C:/Users/hp/OneDrive/Documents/p11l4.py =============
Enter number of students: tarunima
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p11l4.py", line 5, in <module>
    n = int(input("Enter number of students: "))
ValueError: invalid literal for int() with base 10: 'tarunima'

============== RESTART: C:/Users/hp/OneDrive/Documents/p11l4.py =============
Enter number of students: taru diya palak
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p11l4.py", line 5, in <module>
    n = int(input("Enter number of students: "))
ValueError: invalid literal for int() with base 10: 'taru diya palak'

============== RESTART: C:/Users/hp/OneDrive/Documents/p11l4.py =============
Enter number of students: 5
Enter student name: taru
Enter marks: 78
Enter student name: diya
Enter marks: 34
Enter student name: pallu
Enter marks: 79
Enter student name: sattu
Enter marks: 89
Enter student name: binnu
Enter marks: 39

Student Details:
taru : 78
diya : 34
pallu : 79
sattu : 89
binnu : 39

============== RESTART: C:/Users/hp/OneDrive/Documents/p12l4.py =============
Enter number of students: 
============== RESTART: C:/Users/hp/OneDrive/Documents/p12l4.py =============
Enter number of students: 3
Enter name: taru
Enter marks: 78
Enter name: priyanshi
Enter marks: 45
Enter name: bhanu
Enter marks: 89
Maximum marks: 89
Minimum marks: 45

============== RESTART: C:/Users/hp/OneDrive/Documents/p13l4.py =============
Enter a string: hi im tarunima here
Character Frequency:
h : 2
i : 3
  : 3
m : 2
t : 1
a : 2
r : 2
u : 1
n : 1
e : 2

============== RESTART: C:/Users/hp/OneDrive/Documents/p14l4.py =============
Enter number of elements in first dictionary: 3
Enter key: tn
Enter value: 5
Enter key: ns
Enter value: 7
Enter key: kh
Enter value: 6
Enter number of elements in second dictionary: 2
Enter key: tn 
Enter value: 9
Enter key: ns
Enter value: 3
Merged dictionary: {'tn': '5', 'ns': '3', 'kh': '6', 'tn ': '9'}

============== RESTART: C:/Users/hp/OneDrive/Documents/p15l4.py =============
Dictionary sorted by keys:
a : 10
b : 20
c : 30

============== RESTART: C:/Users/hp/OneDrive/Documents/p15l4.py =============
Enter number of elements: 2
Enter key: 34
Enter value: ab
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p15l4.py", line 9, in <module>
    value = int(input("Enter value: "))
ValueError: invalid literal for int() with base 10: 'ab'

============== RESTART: C:/Users/hp/OneDrive/Documents/p15l4.py =============
Enter number of elements: 2
Enter key: tg
Enter value: 8
Enter key: ns
Enter value: 9
Dictionary sorted by keys:
ns : 9
tg : 8

============== RESTART: C:/Users/hp/OneDrive/Documents/p16l4.py =============
Enter number of elements: 
============== RESTART: C:/Users/hp/OneDrive/Documents/p16l4.py =============
Enter number of elements: 3
Enter key: tg
Enter value: 8
Enter key: dt
Enter value: 4
Enter key: pj
Enter value: 9
Dictionary sorted by values:
dt : 4
tg : 8
pj : 9

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l4.py =============
Enter key to update: a
Key not found.

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l4.py =============
Enter key to update: B
Enter new value: 78
Updated dictionary: {'A': 10, 'B': 78, 'C': 30}

============== RESTART: C:/Users/hp/OneDrive/Documents/p18l4.py =============
Enter key to remove: A
Dictionary after removal: {'B': 20, 'C': 30}

============== RESTART: C:/Users/hp/OneDrive/Documents/p19l4.py =============
Enter key to search: B
Key exists in dictionary.

============== RESTART: C:/Users/hp/OneDrive/Documents/p20l4.py =============
Enter number of elements: 2
Enter key: w
Enter value: 09
Enter key: r
Enter value: 78
Dictionary: {'w': 9, 'r': 78}
Sum of values: 87

============== RESTART: C:/Users/hp/OneDrive/Documents/p21l4.py =============
Enter number of elements: 2
Enter key: j
Enter value: 8
Enter key: f
Enter value: 4
Dictionary: {'j': 8, 'f': 4}
Key with maximum value: j
Maximum value: 8

============== RESTART: C:/Users/hp/OneDrive/Documents/p22l4.py =============
Enter n: 3
Dictionary: {1: 1, 2: 4, 3: 9}

============== RESTART: C:/Users/hp/OneDrive/Documents/p23l4.py =============
Enter keys: g
Enter values: 8
Dictionary: {'g': '8'}
d
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    d
NameError: name 'd' is not defined. Did you mean: 'id'?

============== RESTART: C:/Users/hp/OneDrive/Documents/p24l4.py =============
Enter number of elements: 2
Enter key: i
Enter value: 8
Enter key: f
Enter value: 9
Original dictionary: {'i': '8', 'f': '9'}
Inverted dictionary: {'8': 'i', '9': 'f'}

============== RESTART: C:/Users/hp/OneDrive/Documents/p25l4.py =============
Enter a paragraph: hi taru here. what i have to say yaar. im the best

Word Frequency:
hi : 1
taru : 1
here. : 1
what : 1
i : 1
have : 1
to : 1
say : 1
yaar. : 1
im : 1
the : 1
best : 1

============== RESTART: C:/Users/hp/OneDrive/Documents/p26l4.py =============
Enter number of elements in first dictionary: yu
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p26l4.py", line 6, in <module>
    n = int(input("Enter number of elements in first dictionary: "))
ValueError: invalid literal for int() with base 10: 'yu'

============== RESTART: C:/Users/hp/OneDrive/Documents/p26l4.py =============
Enter number of elements in first dictionary: 3
Enter key: u
Enter value: 8
Enter key: h
Enter value: 9
Enter key: s
Enter value: 07
Enter number of elements in second dictionary: 2
Enter key: t
Enter value: 9
Enter key: s
Enter value: 7
Dictionaries are not equal.

============== RESTART: C:/Users/hp/OneDrive/Documents/p27l4.py =============
Enter number of elements: 4
Enter key: h
Enter value: 7
Enter key: d
Enter value: 9
Enter key: h
Enter value: 4
Enter key: k
Enter value: 9
Original dictionary: {'h': '4', 'd': '9', 'k': '9'}
After removing duplicate values: {'h': '4', 'd': '9'}

============== RESTART: C:/Users/hp/OneDrive/Documents/p28l4.py =============
Enter number of students: 3
Enter roll number: 1
Enter name: tg
Enter marks: 89
Enter roll number: 2
Enter name: dt
Enter marks: 78
Enter roll number: pj
Enter name: 49
Enter marks: 56

Student Details:
{'Name': 'tg', 'Roll': '1', 'Marks': 89}
{'Name': 'dt', 'Roll': '2', 'Marks': 78}
{'Name': '49', 'Roll': 'pj', 'Marks': 56}
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p29l4.py =============
Enter number of elements in first dictionary: 2
Enter key: s
Enter value: 78
Enter key: t
Enter value: 89
Enter number of elements in second dictionary: 1
Enter key: t
Enter value: 78
First dictionary: {'s': '78', 't': '89'}
Second dictionary: {'t': '78'}
Common keys: ['t']
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p30l4.py =============
Enter a string: hello babu
Character Frequency Dictionary:
h : 1
e : 1
l : 2
o : 1
  : 1
b : 2
a : 1
u : 1
