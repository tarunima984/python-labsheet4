# Convert list into string without join()

itm = input("Enter list elements: ").split()

r = ""

for itm in itm:
    r = r + itm

print("String:", r)
