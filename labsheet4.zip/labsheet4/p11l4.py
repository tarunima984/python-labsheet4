# Create student dictionary

stu = {}

n = int(input("Enter number of students: "))

for i in range(n):
    name = input("Enter student name: ")
    marks = int(input("Enter marks: "))
    stu[name] = marks

print("\nStudent Details:")

for name in stu:
    print(name, ":", stu[name])
