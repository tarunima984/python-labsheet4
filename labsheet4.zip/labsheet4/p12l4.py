# Find maximum and minimum marks

stu = {}

n = int(input("Enter number of students: "))

for i in range(n):
    name = input("Enter name: ")
    marks = int(input("Enter marks: "))
    stu[name] = marks

first = True

for marks in stu.values():
    if first:
        max = marks
        min = marks
        first = False
    else:
        if marks > max:
            max = marks
        if marks < min:
            min = marks

print("Maximum marks:", max)
print("Minimum marks:", min)
