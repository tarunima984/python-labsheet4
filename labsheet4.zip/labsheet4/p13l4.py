# Count character frequency

txt = input("Enter a string: ")

fq= {}

for char in txt:
    if char in fq:
        fq[char] = fq[char] + 1
    else:
        fq[char] = 1

print("Character Frequency:")

for char in fq:
    print(char, ":", fq[char])
