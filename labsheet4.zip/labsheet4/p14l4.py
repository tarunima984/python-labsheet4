# Merge two dictionaries

dict1 = {}
dict2 = {}

n = int(input("Enter number of elements in first dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict1[key] = value

n = int(input("Enter number of elements in second dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict2[key] = value

merged = dict1.copy()

for key in dict2:
    merged[key] = dict2[key]

print("Merged dictionary:", merged)
