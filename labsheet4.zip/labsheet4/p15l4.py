# Sort a dictionary by keys

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = int(input("Enter value: "))
    data[key] = value

keys = list(data.keys())

# Sort keys
for i in range(len(keys)):
    for j in range(i + 1, len(keys)):
        if keys[i] > keys[j]:
            keys[i], keys[j] = keys[j], keys[i]

print("Dictionary sorted by keys:")

for key in keys:
    print(key, ":", data[key])
