# Sort a dictionary by values

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = int(input("Enter value: "))
    data[key] = value

items = list(data.items())

# Sort according to values
for i in range(len(items)):
    for j in range(i + 1, len(items)):
        if items[i][1] > items[j][1]:
            items[i], items[j] = items[j], items[i]

print("Dictionary sorted by values:")

for key, value in items:
    print(key, ":", value)
