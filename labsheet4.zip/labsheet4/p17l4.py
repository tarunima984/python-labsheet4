# Update value of a key

data = {"A": 10, "B": 20, "C": 30}

key = input("Enter key to update: ")

if key in data:
    value = int(input("Enter new value: "))
    data[key] = value
    print("Updated dictionary:", data)
else:
    print("Key not found.")
