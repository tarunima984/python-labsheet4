# Remove a key

data = {"A": 10, "B": 20, "C": 30}

key = input("Enter key to remove: ")

if key in data:
    del data[key]
    print("Dictionary after removal:", data)
else:
    print("Key not found.")
