# Check whether key exists

data = {"A": 10, "B": 20, "C": 30}

key = input("Enter key to search: ")

if key in data:
    print("Key exists in dictionary.")
else:
    print("Key does not exist.")
