# Find sum and average of list elements

n = list(map(int, input("Enter numbers separated by space: ").split()))

total = 0

for num in n:
    total = total + num

avg = total / len(n)

print("List:", n)
print("Sum:", total)
print("Average:", avg)
