# Find sum of all dictionary values

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = int(input("Enter value: "))
    data[key] = value

total = 0

for value in data.values():
    total = total + value

print("Dictionary:", data)
print("Sum of values:", total)
