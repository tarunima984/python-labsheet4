# Find key with maximum value

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = int(input("Enter value: "))
    data[key] = value

first = True

for key in data:
    if first:
        max_key = key
        max_value = data[key]
        first = False
    else:
        if data[key] > max_value:
            max_value = data[key]
            max_key = key

print("Dictionary:", data)
print("Key with maximum value:", max_key)
print("Maximum value:", max_value)
