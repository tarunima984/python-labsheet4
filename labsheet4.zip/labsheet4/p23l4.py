# Convert two lists into dictionary

keys = input("Enter keys: ").split()
values = input("Enter values: ").split()

data = {}

for i in range(len(keys)):
    data[keys[i]] = values[i]

print("Dictionary:", data)
