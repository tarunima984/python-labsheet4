# Invert a dictionary

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    data[key] = value

inverted = {}

for key in data:
    inverted[data[key]] = key

print("Original dictionary:", data)
print("Inverted dictionary:", inverted)
