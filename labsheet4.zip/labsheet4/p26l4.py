# Check whether two dictionaries are equal

dict1 = {}
dict2 = {}

n = int(input("Enter number of elements in first dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict1[key] = value

n = int(input("Enter number of elements in second dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict2[key] = value

if dict1 == dict2:
    print("Both dictionaries are equal.")
else:
    print("Dictionaries are not equal.")
