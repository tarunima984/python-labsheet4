# Remove duplicate values from dictionary

data = {}

n = int(input("Enter number of elements: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    data[key] = value

new_dict = {}

for key in data:
    value = data[key]
    found = False

    for old_value in new_dict.values():
        if old_value == value:
            found = True
            break

    if not found:
        new_dict[key] = value

print("Original dictionary:", data)
print("After removing duplicate values:", new_dict)
