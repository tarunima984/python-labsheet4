# Find common keys between two dictionaries

dict1 = {}
dict2 = {}

n = int(input("Enter number of elements in first dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict1[key] = value

n = int(input("Enter number of elements in second dictionary: "))

for i in range(n):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict2[key] = value

common = []

for key in dict1:
    if key in dict2:
        common.append(key)

print("First dictionary:", dict1)
print("Second dictionary:", dict2)
print("Common keys:", common)
