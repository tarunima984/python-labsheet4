# Remove negative numbers from a list

n = list(map(int, input("Enter numbers: ").split()))
pos = []

for num in n:
    if num >= 0:
        pos.append(num)

print("List after removing negative numbers:", pos)
