# Find product of all elements

n = list(map(int, input("Enter numbers: ").split()))

pro = 1

for num in n:
    pro = pro * num

print("Product:", pro)
