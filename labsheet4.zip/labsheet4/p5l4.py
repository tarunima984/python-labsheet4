# Create list of squares

n = int(input("Enter n: "))

sq = []

for i in range(1, n + 1):
    sq.append(i * i)

print("List of squares:", sq)
