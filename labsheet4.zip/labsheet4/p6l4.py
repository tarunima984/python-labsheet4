# Split a list into two halves

num = list(map(int, input("Enter numbers: ").split()))

mid = len(num) // 2

first = num[:mid]
second = num[mid:]

print("First half:", first)
print("Second half:", second)
