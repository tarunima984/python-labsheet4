# Check whether list is sorted

n = list(map(int, input("Enter numbers: ").split()))

sort_l = True

for i in range(len(n) - 1):
    if n[i] > n[i + 1]:
        sort_l = False
        break

if sort_l:
    print("List is sorted.")
else:
    print("List is not sorted.")
