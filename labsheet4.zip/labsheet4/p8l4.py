# Find pairs with given sum

n = list(map(int, input("Enter numbers: ").split()))
t = int(input("Enter target sum: "))

found = False

for i in range(len(n)):
    for j in range(i + 1, len(n)):
        if n[i] + n[j] == t:
            print("Pair:", n[i], n[j])
            found = True

if not found:
    print("No pair found.")
